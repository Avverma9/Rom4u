import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Tool = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
   
        const response = await axios.get('https://youtube-pn9u.onrender.com/tool');
        setData(response.data);
     
    };
    fetchData();
  }, []);

  return (
    <>
      {data.map((tool) => (
        <div key={tool._id}>
          <p>{tool.name}</p>
          <a href={tool.link} target="_blank" rel="noopener noreferrer">
              Download
            </a>
        </div>
      ))}
    </>
  );
};

export default Tool;
